Stolen from MinecraftEarthMap.

credit here: https://github.com/MattiBorchers/MinecraftEarthMap

Paints terracotta layers onto terrain. Looks pretty nice.
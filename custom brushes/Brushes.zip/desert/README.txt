These are special layers designed to add vanilla-like foliage to your world. They all modify the terrain cover, so keep that in mind.

Only import and use the "desert.layer" file, WorldPainter will automatically extract the "cover" and "terrain" bits (which you shouldn't use alone, but I guess you could)

I added grass to the "cover" layer, for the sole reason of reducing the amount of dead shrub and cactus that generate on the sand.
Since grass cannot grow on sand, it just acts as an "empty" spot on the ground.
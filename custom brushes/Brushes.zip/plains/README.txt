Various layers for plains-like stuff. Plenty of flowers and grass, barely any trees.

All the tree layers are identical to their "forest" versions, except significantly more "sparse."
Ignore the "XXX_trees.layer" files, and instead use the "XXX_plains" or the "grass_flowers"

Relative percentages are identical to the normal oak_birch_bee and oak_birch trees, just significantly more sparse

The sparseness is set to 2000 (at 50%, so 596? at 100%), but actually, this is set to 50% factor in the final combined layer,
so it is effectively 4000 (at 50%, so 1138? at 100%)
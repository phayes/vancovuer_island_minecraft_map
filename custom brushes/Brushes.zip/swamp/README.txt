Swamps are a bit unique in that the Blue Orchid is the only flower that spawns here during world
generation, and can be grown only here when using bone meal. Obviously, for a vanilla experience,
no flower other than the Blue Orchid should be placed in swamps, and you should set the biome so
that players can grow more Blue Orchids when using bone meal.


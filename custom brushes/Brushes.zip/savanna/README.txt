x = acacia = 90%
y = oak    = 10%

18x = 32y
9(9x) = 16y
81x = 16y

acacia: 81% (2592 out of 2880, 90%)
oak:    16% (288 out of 2880, 10%)
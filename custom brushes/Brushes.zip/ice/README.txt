custom ice terrain

deep snow, then a bit of packed ice, then a lot of blue ice.

idk, just seemed cool so I made it lol
